package com.example.loanapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Repaymennt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repaymennt);
        findViewById(R.id.button5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the RegisterActivity when the "Register" button is clicked
                Intent intent = new Intent(Repaymennt.this, RepaymentMethod.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.back1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the RegisterActivity when the "Register" button is clicked
                Intent intent = new Intent(Repaymennt.this, Requests.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.imageButton4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the RegisterActivity when the "Register" button is clicked
                Intent intent = new Intent(Repaymennt.this, Profile.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.imageButton3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the RegisterActivity when the "Register" button is clicked
                Intent intent = new Intent(Repaymennt.this, Requests.class);
                startActivity(intent);
            }
        });

    }
}