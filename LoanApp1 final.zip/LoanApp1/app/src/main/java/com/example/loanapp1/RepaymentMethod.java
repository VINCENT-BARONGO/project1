package com.example.loanapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class RepaymentMethod extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repayment_method);
        findViewById(R.id.back2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the RegisterActivity when the "Register" button is clicked
                Intent intent = new Intent(RepaymentMethod.this, Repaymennt.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.back1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the RegisterActivity when the "Register" button is clicked
                Intent intent = new Intent(RepaymentMethod.this, Repaymennt.class);
                startActivity(intent);
            }
        });
    }
}